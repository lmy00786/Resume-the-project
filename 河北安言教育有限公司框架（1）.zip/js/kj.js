$(document).ready(function () {
    //二级导航
    $("header nav .nav-md > li").hover(function () {
        $(this).children("ul").stop().slideToggle(500);
    })
    //轮播图左右点击按钮
    $("header #slidershow > a ").mousedown(function () {
        $(this).css("opacity", "1")
    });
    $("header #slidershow > a ").mouseup(function () {
        $(this).css("opacity", "0.5")
    });
    $("header .header .wrap .logo span ").click(function () {
        if ($(this).next(".sjdnav").css('height') == '0px') {
            $(this).next(".sjdnav").animate({"height":"336px"})
        }else if($(this).next(".sjdnav").css('height') == '336px'){
            $(this).next(".sjdnav").animate({"height":"0px"})
        }
    })
})














